class Q3_1:
    def f1(self, a, start): 
        #a is the adjacency matrix representing the given graph
        # start is a starting point 
        pass
        