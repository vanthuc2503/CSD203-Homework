class Q3_3:
    def f3(self, a, start, end): 
        #a is the adjacency matrix representing the given graph
        # start is a starting point
        # end is a ending point
        pass
        